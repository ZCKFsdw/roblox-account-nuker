# Roblox-Mass-Tools

### Setup
1. Open settings.json
2. Put the roblox account cookie in there
3. If the cookie is from someone else, Change `Bypass` to `true`
4. Install the packages in requirements.txt if you don't have them
5. Run main.py
### Features:
- [x] - **Open Source**
- [x] - **Multi-Cookies**
- [x] - **Display Cookie Info**
  - [x] - **Display Birthday**
  - [x] - **Display Gender**
  - [x] - **Display Robux Count**
  - [x] - **Display Country**
  - [x] - **Display Last Location**
  - [x] - **Display If Pin is Enabled**
  - [x] - **Display If Cookie is Email verified**
  - [x] - **Display If Cookie is Age verified**
- [x] - **Mass Group Leaver**
- [x] - **Mass Unfavorite Games**
- [x] - **Mass Unfollow**
- [x] - **Mass Unfriend**
- [x] - **Mass Delete t-shirts**
- [x] - **Unregion Lock Cookie**
- [x] - **Nuke Account/Cookie**
  - [x] - **Change Name**
  - [x] - **Change Description**
  - [x] - **Message All**
  - [x] - **Leaves Groups**
  - [x] - **Unfriend Everyone**
  - [x] - **Change Games Names**
  - [x] - **Change Games Descriptions**
  - [x] - **Change Account Avatar**
- [x] - **Pin Cracker**
- [x] - **Steal Group Clothes**
  - [x] - **Detects Copyrighted assets**
  - [x] - **Changes Assets Template**
- [x] - **Upload clothes** 
- [x] - **Mass Create Gamepasses** 
- [x] - **Spam User Inbox** 
- [x] - **Check Group ID** 
- [x] - **Randomize Avatar**
- [x] - **Mass Create Outfits**
- [x] - **Mass Delete Outfits**
- [x] - **Auto Ally**
- [x] - **Mass Off Sale Gamepasses**

## Preview:
![image](https://github.com/Aspectise/Roblox-Mass-Tools/assets/90333100/c0bc9892-05a5-4e7d-b636-c30571930214)

## ⭐
- If you like the tool please star the repo 😊

## Help
If you need help or want to report an error join the [Discord](https://discord.gg/deathsniper)
